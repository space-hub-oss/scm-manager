Usage of this tool is under the MIT licence

An SCM Manager that can update a repository and build the affected modules

Disclaimer: This tool is under development and more custom operations may gain support within time.
Supported operations will remain supported.

Basic usage scenario:
* Unzip the packaged archive under a directory of choice.
* Add an environment variable, %SCM_MANAGER_HOME%, pointing to the 'scm-manager-client' directory where the archive has
been extracted.
* Include the scm manager binaries to your system path by appending "%SCM_MANAGER_HOME%\bin" to the %PATH% variable.
* Open up a windows shell and run the following command: scm-manager
* Cheers.